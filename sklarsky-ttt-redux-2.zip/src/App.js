import React, { Component } from 'react';
import './App.css';
import Button from 'antd/lib/button';
import checkTicTacToe from './checkTicTacToe';
import Board from './components/board';
import Scoreboard from './components/scoreboard';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { takeTurn, resetBoard, logVictory } from './actions';

class App extends Component {
  setStatusButtonLabel() {
    let winner = checkTicTacToe(this.props.board);

    if (winner) {
      this.props.logVictory(winner);
      return `${winner} wins!`;
    } else {
      return 'Reset';
    }
  }

  handleClick(row, column) {
    let nextTurn = this.props.turn === 'X' ? 'O' : 'X';
    this.props.takeTurn(row, column, nextTurn);
  }

  resetBoard(){
    this.props.resetBoard();
  }

  render() {
    return (
      <div className="App">
        <Button
          className="reset"
          onClick={()=>this.resetBoard()}>
          {this.setStatusButtonLabel()}
        </Button>

        <Board board={this.props.board} handleClick={(row, column)=>this.handleClick(row, column)}/>

        <Scoreboard score={this.props.score}/>

      </div>
    );
  }
}

const mapStateToProps = (state) => { 
  return {
    board: state.board,
    turn: state.turn,
    score: state.score
  };
};

const mapDispatchToProps = (dispatch) => {
  return bindActionCreators({
    takeTurn: takeTurn,
    resetBoard: resetBoard,
    logVictory: logVictory
  }, dispatch);
};
 
export default connect(mapStateToProps, mapDispatchToProps)(App);
