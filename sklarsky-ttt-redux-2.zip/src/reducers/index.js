import { getInitialState } from '../index';

const game = (state = {}, action) => {
  switch (action.type) {
    case 'TAKE_TURN':
      let board = state.board.slice();
      board[action.row][action.column] = state.turn;
      return {
        ...state,
        turn: action.nextTurn
      };
    case 'RESET_BOARD':
      let refreshedState = getInitialState();
      refreshedState.score = state.score //keep score the same
      return refreshedState;
    case 'LOG_VICTORY':
      let {score} = state;
      score[action.winner]++;
      return {
        ...state,
        score: score
      }
    default:
      return state;
  }
};

export default game;
